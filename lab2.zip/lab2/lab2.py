import math

print("Місце роботи 1")
p_A = []
X_A = []
for i in range(2):
    print("Результат", i+1)
    print("ймовірність:")
    p_A.append(float(input()))
    print("прибуток:")
    X_A.append(int(input()))
    print("\n")

print("Місце роботи 2")
p_B = []
X_B = []
for i in range(2):
    print("Результат", i+1)
    print("ймовірність:")
    p_B.append(float(input()))
    print("прибуток:")
    X_B.append(int(input()))
    print("\n")

print("Сподіваний результат:")
M_A = 0
M_B = 0
for i in range(2):
    M_A += p_A[i] * X_A[i]
    M_B += p_B[i] * X_B[i]
print("MA+ =",M_A)
print("MB+ =",M_B)
if (M_A > M_B):
    print("макс. очікуваний прибуток: ", M_A," у випадку 1")
elif (M_A < M_B):
    print("макс. очікуваний прибуток: ", M_B," у випадку 2")
else:
    print("макс. очікуваний прибуток однаковий")
print("\n")

print("Варіація(дисперсія):")
V_A = 0
V_B = 0
for i in range(2):
    V_A += pow(X_A[i]-M_A,2) * p_A[i]
    V_B += pow(X_B[i]-M_B,2) * p_B[i]
print("VA- =",V_A)
print("VB- =",V_B)
if (V_A < V_B):
    print("мін. відхидення від очікуваного прибутку: ", V_A," у випадку 1")
elif (V_A > V_B):
    print("мін. відхидення від очікуваного прибутку: ", V_B," у випадку 2")
else:
    print("мін. відхидення від очікуваного прибутку однакове")
print("\n")

print("Середньоквадратичне відхилення(сігма):")
S_A = math.sqrt(V_A)
S_B = math.sqrt(V_B)
print("SA- =",S_A)
print("SB- =",S_B)
