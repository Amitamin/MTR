def pr():
    p = float(input())
    if ((p > 0) and (p < 1)):
        return p;
    else:
        print("This value is wrong!")
        print("Enter probability of rain (from 0 to 1)")
        pr()
        
print("Enter probability of rain (from 0 to 1)")
probability_rain = pr()

probability_sun = float(1 - probability_rain)

print("How do you feel in the forest when the weather is sunny?(from 1 to 10)")
forest_sun = float(input())
print("How do you feel in the forest when the weather is rainy?(from 1 to 10)")
forest_rain = float(input())
print("How do you feel at home when the weather is sunny?(from 1 to 10)")
home_sun = float(input())
print("How do you feel at home when the weather is rainy?(from 1 to 10)")
home_rain = float(input())
print("\n")

U_forest = probability_sun * forest_sun + probability_rain * forest_rain
U_home = probability_sun * home_sun + probability_rain * home_rain

print("Results:")
print("Forest - ", U_forest)
print("Home - ", U_home, "\n")

if(U_forest > U_home):
    print("Let's go to the forest!")
else:
    print("Stay at home!")
    
